
void my_ls(char *dname, int i);